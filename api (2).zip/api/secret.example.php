<?php
// Salin file ini menjadi secret.php (jangan di-commit) lalu isi API key Gemini.
// File ini dibaca oleh api/index.php untuk fitur generator Asesmen.

$GEMINI_API_KEY = '';
