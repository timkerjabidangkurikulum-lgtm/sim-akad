<?php
// Konfigurasi umum SIM-AKAD (aman untuk dibagikan sebagai template).
// Salin file ini menjadi api/settings.php lalu sesuaikan nilainya.

// Tempat penandatanganan pada dokumen export.
$SIMAKAD_PLACE = 'Banggai';

// Nama Kepala Madrasah untuk blok tanda tangan.
$SIMAKAD_HEAD_TITLE = 'Kepala Madrasah';
$SIMAKAD_HEAD_NAME = 'Muhammad Basri,S.Pd.,M.Pd.';
$SIMAKAD_HEAD_NIP = '197006141994011001';