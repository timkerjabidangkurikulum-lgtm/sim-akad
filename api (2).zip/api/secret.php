<?php
// Rahasia server (JANGAN DISEBARKAN / JANGAN DI-COMMIT)
// Isi API key Gemini di sini.

$GEMINI_API_KEY = 'AIzaSyBeGToGdPYLXuYc2R1jL73chU9WTG141wE';
